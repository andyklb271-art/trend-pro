// server.js  — Render (HTTPS) + PKCE + CORS + Cookies
import 'dotenv/config';
import express from 'express';
import cookieParser from 'cookie-parser';
import cors from 'cors';
import crypto from 'crypto'; // PKCE

const app = express();

// ===== Config =====
const {
  PORT = 3000,
  NODE_ENV = 'production',
  FRONTEND_ORIGIN = 'http://localhost:5173',                 // lokales UI
  REDIRECT_URI = 'https://trend-pro.onrender.com/auth/tiktok/callback',
  TIKTOK_CLIENT_KEY,
  TIKTOK_CLIENT_SECRET,
  SESSION_SECRET = 'change-me',
} = process.env;

if (!TIKTOK_CLIENT_KEY || !TIKTOK_CLIENT_SECRET) {
  console.warn('⚠️  TikTok CLIENT_KEY/CLIENT_SECRET fehlen!');
}

app.use(express.json());
app.use(cookieParser(SESSION_SECRET));

// ===== CORS (Frontend lokal) =====
const ALLOWED_ORIGINS = [
  FRONTEND_ORIGIN,
  'http://localhost:5173',
  'http://127.0.0.1:5173',
].filter(Boolean);

app.use(
  cors({
    origin(origin, cb) {
      if (!origin) return cb(null, true);
      cb(null, ALLOWED_ORIGINS.includes(origin));
    },
    credentials: true,
  })
);
app.options('*', cors());

// ===== Mini-Session / PKCE-Store =====
// Für mehrere gleichzeitige Logins: state -> code_verifier
const stateStore = new Map();
// Einfache "Session" nur für Demo
let SESSION = { user: null, access_token: null, refresh_token: null, expires_at: null };

// ===== Helpers =====
const cookieOpts = {
  httpOnly: true,
  signed: true,
  // Cross-Site, weil Backend (Render) ≠ Frontend (localhost):
  sameSite: 'None',
  secure: true, // Render ist HTTPS
  maxAge: 7 * 24 * 60 * 60 * 1000,
};

// ===== Routes =====
app.get('/health', (_req, res) => res.json({ ok: true, mode: NODE_ENV }));

app.get('/me', (_req, res) => {
  if (!SESSION.user) return res.status(401).json({ loggedIn: false, user: null });
  res.json({ loggedIn: true, user: SESSION.user });
});

app.post('/api/logout', (_req, res) => {
  SESSION = { user: null, access_token: null, refresh_token: null, expires_at: null };
  res.clearCookie('trendpro_sid', { ...cookieOpts });
  res.json({ ok: true });
});

// ---- Start OAuth (PKCE) ----
app.get('/auth/tiktok/login', (req, res) => {
  const state = crypto.randomBytes(16).toString('base64url');

  // PKCE: Verifier + Challenge
  const code_verifier = crypto.randomBytes(32).toString('base64url');
  const code_challenge = crypto
    .createHash('sha256')
    .update(code_verifier)
    .digest('base64url');

  stateStore.set(state, { code_verifier, ts: Date.now() });

  const scope = encodeURIComponent('user.info.basic,user.info.profile');
  const url =
    'https://www.tiktok.com/v2/auth/authorize/' +
    `?client_key=${encodeURIComponent(TIKTOK_CLIENT_KEY)}` +
    `&response_type=code` +
    `&scope=${scope}` +
    `&redirect_uri=${encodeURIComponent(REDIRECT_URI)}` +
    `&state=${state}` +
    `&code_challenge=${code_challenge}` +
    `&code_challenge_method=S256`;

  res.redirect(url);
});

// ---- OAuth Callback ----
app.get('/auth/tiktok/callback', async (req, res) => {
  try {
    const { code, state } = req.query;
    if (!code || !state) return res.status(400).send('Missing code/state');

    const entry = stateStore.get(state);
    stateStore.delete(state);
    if (!entry?.code_verifier) return res.status(400).send('PKCE verifier not found');

    // Token holen
    const tokenResp = await fetch('https://open.tiktokapis.com/v2/oauth/token/', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        client_key: TIKTOK_CLIENT_KEY,
        client_secret: TIKTOK_CLIENT_SECRET,
        code: String(code),
        grant_type: 'authorization_code',
        redirect_uri: REDIRECT_URI,
        code_verifier: entry.code_verifier,
      }),
    });
    const tokenJson = await tokenResp.json().catch(() => ({}));
    if (!tokenResp.ok || !tokenJson?.data?.access_token) {
      console.error('Token error:', tokenJson);
      return res.status(400).json({ error: 'Token exchange failed', details: tokenJson });
    }

    const { access_token, refresh_token, expires_in } = tokenJson.data;

    // Userinfo
    const meResp = await fetch(
      'https://open.tiktokapis.com/v2/user/info/?fields=open_id,display_name,avatar_url',
      { headers: { Authorization: `Bearer ${access_token}` } }
    );
    const meJson = await meResp.json().catch(() => ({}));
    if (!meResp.ok || !meJson?.data?.user) {
      console.error('Userinfo error:', meJson);
      return res.status(400).json({ error: 'Userinfo failed', details: meJson });
    }

    // Session setzen
    SESSION = {
      user: meJson.data.user,
      access_token,
      refresh_token,
      expires_at: Date.now() + (Number(expires_in) || 0) * 1000,
    };

    // Cookie (Demo-Session)
    res.cookie('trendpro_sid', '1', cookieOpts);

    // zurück ins (lokale) Frontend
    res.redirect(`${FRONTEND_ORIGIN}/me`);
  } catch (e) {
    console.error('Callback error:', e);
    res.status(500).send('TikTok Callback Error');
  }
});

// ===== Start =====
app.listen(Number(PORT), '0.0.0.0', () => {
  console.log(`✅ API on :${PORT}`);
  console.log(`   FRONTEND_ORIGIN: ${FRONTEND_ORIGIN}`);
  console.log(`   REDIRECT_URI   : ${REDIRECT_URI}`);
});
